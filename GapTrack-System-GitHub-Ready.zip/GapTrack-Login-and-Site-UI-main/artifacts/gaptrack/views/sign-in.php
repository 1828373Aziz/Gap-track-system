<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="سجّل الدخول إلى GapTrack لمتابعة إشارات الشحنات والتغطية.">
  <meta name="theme-color" content="#163c3b">
  <link rel="icon" type="image/svg+xml" href="favicon.svg">
  <title>تسجيل الدخول — GapTrack</title>
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="sign-in-page">
  <main class="sign-in-layout">
    <section class="sign-in-intro" aria-labelledby="sign-in-brand">
      <a class="brand sign-in-brand" href="index.php" aria-label="GapTrack، الصفحة الرئيسية">
        <span class="brand-mark" aria-hidden="true">G</span>
        <span>
          <b id="sign-in-brand">GapTrack</b>
          <small>وضوح لكل رحلة</small>
        </span>
      </a>

      <div class="sign-in-story">
        <p class="eyebrow">إشارات أوضح. قرارات أسرع.</p>
        <h1>كل رحلة<br><span>لها إشارة.</span></h1>
        <p class="sign-in-description">تابع فجوات الاتصال، وافهم مناطق التغطية الضعيفة، والتقط ما يستحق الانتباه على الطريق.</p>

        <div class="signal-illustration" aria-hidden="true">
          <svg viewBox="0 0 520 280" role="presentation" focusable="false">
            <path class="signal-grid" d="M0 56H520M0 112H520M0 168H520M0 224H520M65 0V280M130 0V280M195 0V280M260 0V280M325 0V280M390 0V280M455 0V280" />
            <path class="signal-route-shadow" d="M38 211C90 195 106 128 166 142S248 209 294 163s65-91 111-79 48 28 77 3" />
            <path class="signal-route" d="M38 211C90 195 106 128 166 142S248 209 294 163s65-91 111-79 48 28 77 3" />
            <circle class="signal-halo" cx="294" cy="163" r="23" />
            <circle class="signal-node" cx="38" cy="211" r="6" />
            <circle class="signal-node" cx="166" cy="142" r="6" />
            <circle class="signal-node signal-node-gap" cx="294" cy="163" r="7" />
            <circle class="signal-node" cx="405" cy="84" r="6" />
            <circle class="signal-node signal-node-end" cx="482" cy="87" r="6" />
            <rect class="signal-label" x="314" y="177" width="112" height="35" rx="8" />
            <circle class="signal-label-dot" cx="402" cy="194" r="4" />
            <path class="signal-wave" d="M56 70c12-12 32-12 44 0M66 80c7-7 18-7 25 0M76 90c2-2 5-2 7 0" />
          </svg>
          <span class="signal-caption">مسار الرحلة · تغطية متغيرة</span>
        </div>
      </div>

      <p class="sign-in-footnote">وضوح الإشارة، قرار أفضل</p>
    </section>

    <section class="sign-in-main" aria-labelledby="sign-in-heading">
      <div class="sign-in-content">
        <p class="sign-in-kicker">مساحة عملك</p>
        <h2 id="sign-in-heading">مرحبًا بعودتك</h2>
        <p class="sign-in-support">سجّل الدخول لمتابعة الشحنات ومراجعة التنبيهات التشغيلية.</p>

        <div
          id="clerk-sign-in"
          class="clerk-mount"
          data-clerk-mount="sign-in"
          aria-label="منطقة تسجيل الدخول"
          aria-live="polite"
        ></div>

        <p class="sign-in-assurance">بيانات التشغيل تبقى ضمن مساحة فريقك.</p>
      </div>
      <footer class="sign-in-footer">
        <span>GapTrack</span>
        <span>منصة متابعة الإشارات التشغيلية</span>
      </footer>
    </section>
  </main>
  <script id="gaptrack-clerk-config" type="application/json"><?= json_encode([
    'publishableKey' => getenv('VITE_CLERK_PUBLISHABLE_KEY') ?: getenv('CLERK_PUBLISHABLE_KEY') ?: '',
    'proxyUrl' => getenv('VITE_CLERK_PROXY_URL') ?: '',
  ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?></script>
  <script src="assets/js/auth.bundle.js" defer></script>
</body>
</html>
