    </div>
    <footer class="page-footer"><span>GapTrack · وضوح الإشارة، قرار أفضل</span><span>بيانات العرض توضيحية وليست بيانات تشغيل فعلية</span></footer>
  </main>
</div>
<script src="assets/js/app.js" defer></script>
<script id="gaptrack-clerk-config" type="application/json"><?= json_encode([
  'publishableKey' => getenv('VITE_CLERK_PUBLISHABLE_KEY') ?: getenv('CLERK_PUBLISHABLE_KEY') ?: '',
  'proxyUrl' => getenv('VITE_CLERK_PROXY_URL') ?: '',
], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?></script>
<script src="assets/js/auth.bundle.js" defer></script>
</body>
</html>
