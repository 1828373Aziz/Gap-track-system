import { defineConfig } from "vite";

export default defineConfig({
  build: {
    lib: {
      entry: "src/auth.ts",
      name: "GapTrackAuth",
      formats: ["iife"],
      fileName: () => "auth.bundle.js",
    },
    outDir: "dist/auth",
    emptyOutDir: true,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
      },
    },
  },
});
